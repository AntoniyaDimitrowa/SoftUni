package bg.softuni.productshop.domain.models.category;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CategoryImportDTO {
    private String name;
}
