package bg.softuni.productshop.domain.models.product;

import java.math.BigDecimal;

public class ProductImportDTO {
    private String name;
    private BigDecimal price;
}
