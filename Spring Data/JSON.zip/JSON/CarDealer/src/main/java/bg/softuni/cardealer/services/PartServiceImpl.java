package bg.softuni.cardealer.services;

import org.springframework.stereotype.Service;

@Service
public class PartServiceImpl implements PartService {
}
