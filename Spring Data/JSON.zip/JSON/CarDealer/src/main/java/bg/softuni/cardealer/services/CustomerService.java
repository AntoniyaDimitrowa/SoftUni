package bg.softuni.cardealer.services;

public interface CustomerService {
}
