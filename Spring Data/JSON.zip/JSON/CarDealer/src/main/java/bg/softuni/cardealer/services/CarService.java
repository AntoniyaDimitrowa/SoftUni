package bg.softuni.cardealer.services;

public interface CarService {
}
