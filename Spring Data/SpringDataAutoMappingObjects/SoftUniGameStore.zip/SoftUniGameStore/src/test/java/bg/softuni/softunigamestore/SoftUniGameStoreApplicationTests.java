package bg.softuni.softunigamestore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftUniGameStoreApplicationTests {

    @Test
    void contextLoads() {
    }

}
