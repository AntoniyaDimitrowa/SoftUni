package bg.softuni.softunigamestore.services.order;

public class OrderServiceImpl implements OrderService {
}
