package bg.softuni.softunigamestore.services.game;

public interface GameService {
    String add(String[] args);
    String delete(String[] args);
    String edit(String[] args);
}
