package databaseOperations;

public class Adding {
    public static void addPatient(String info) {
        //TODO
    }

    public static void addVisitation(String info, String patientInfo) {
        //TODO
    }
}
