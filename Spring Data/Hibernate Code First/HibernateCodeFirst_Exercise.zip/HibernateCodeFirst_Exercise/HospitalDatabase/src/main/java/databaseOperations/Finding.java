package databaseOperations;

import entities.Patient;
import entities.Visitation;

import java.util.List;

public class Finding {
    public static Patient findPatientByFullNameAndBirthDate(String info) {
        //TODO
        return null;
    }

    public static List<Visitation> findVisitationsByDate(String date) {
        //TODO
        return null;
    }
}
