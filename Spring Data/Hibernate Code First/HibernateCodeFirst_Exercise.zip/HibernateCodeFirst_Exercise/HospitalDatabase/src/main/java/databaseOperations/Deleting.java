package databaseOperations;

public class Deleting {
    public static void deletePatientByFullNameAndBirthDate(String info) {
        //TODO
    }
}
