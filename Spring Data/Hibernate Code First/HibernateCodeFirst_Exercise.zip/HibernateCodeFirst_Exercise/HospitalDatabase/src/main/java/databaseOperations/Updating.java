package databaseOperations;

public class Updating {
    public static void updatePatient(String info) {
        //TODO
    }

    public static void updateVisitation(String info) {
        //TODO
    }

    public static void updateDiagnose(String info) {
        //TODO
    }

    public static void updateMedicament(String oldName, String newName) {
        //TODO
    }
}
