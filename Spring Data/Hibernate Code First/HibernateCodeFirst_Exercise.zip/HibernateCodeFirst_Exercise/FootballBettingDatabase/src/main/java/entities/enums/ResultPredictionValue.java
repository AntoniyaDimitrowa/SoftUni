package entities.enums;

public enum ResultPredictionValue {
    Home_Team_Win,
    Draw_Game,
    Away_Team_Win
}
