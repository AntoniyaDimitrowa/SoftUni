package entities.enums;

public enum TeamShortName {
    JUV, LIV, ARS
}
