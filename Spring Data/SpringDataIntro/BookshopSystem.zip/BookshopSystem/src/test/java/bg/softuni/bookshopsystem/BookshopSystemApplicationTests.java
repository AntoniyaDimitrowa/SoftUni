package bg.softuni.bookshopsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookshopSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
