package bg.softuni.bookshopsystem.domain.enums;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
