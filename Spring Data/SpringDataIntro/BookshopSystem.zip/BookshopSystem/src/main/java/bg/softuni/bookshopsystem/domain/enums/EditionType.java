package bg.softuni.bookshopsystem.domain.enums;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
