enum Constants {
    ;
    static final String USER_KEY = "user";
    static final String USER_VALUE = "root";

    static final String PASSWORD_KEY = "password";
    static final String PASSWORD_VALUE = "A123s456D789$";

    static final String JDBC_MYSQL_URL_MINIONS = "jdbc:mysql://localhost:3306/minions_db";

    static final String COLUMN_LABEL_NAME = "name";
    static final String COLUMN_LABEL_AGE = "age";
}
