package P02_Shapes;



public class Main {
    public static void main(String[] args) {
        Shape circle = new Circle(10.0);
        Shape rectangle = new Rectangle(3.0, 4.0);

        System.out.println(circle.getArea());
        System.out.println(circle.getPerimeter());
        System.out.println(rectangle.getArea());
        System.out.println(rectangle.getPerimeter());

    }
}
