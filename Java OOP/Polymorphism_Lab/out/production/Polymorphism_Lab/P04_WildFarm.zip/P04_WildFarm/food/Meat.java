package P04_WildFarm.food;

public class Meat extends Food {
    public Meat(int quantity) {
        super(quantity);
    }
}
