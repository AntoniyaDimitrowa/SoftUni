package P04_WildFarm.food;

public enum FoodType {
    Meat, Vegetable
}
