package P04_WildFarm.animal;

public enum AnimalType {
    Cat, Tiger, Zebra, Mouse
}
