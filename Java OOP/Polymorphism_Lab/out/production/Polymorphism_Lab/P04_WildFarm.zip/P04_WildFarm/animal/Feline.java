package P04_WildFarm.animal;

public abstract class Feline extends Mammal {
    public Feline(String name, Double weight, AnimalType type, String livingRegion) {
        super(name, weight, type, livingRegion);
    }
}
