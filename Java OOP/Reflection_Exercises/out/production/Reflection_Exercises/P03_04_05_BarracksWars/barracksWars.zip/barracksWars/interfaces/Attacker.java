package P03_04_05_BarracksWars.barracksWars.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
