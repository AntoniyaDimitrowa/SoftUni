package P03_04_05_BarracksWars.barracksWars.interfaces;

public interface Unit extends Destroyable, Attacker {
}
