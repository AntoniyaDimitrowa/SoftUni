package P03_04_05_BarracksWars.barracksWars.interfaces;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
