package P03_PlayersAndMonsters;

public class Main {
    public static void main(String[] args) {

    }
}
