package P03_BirthdayCelebrations;

public interface Identifiable {
    String getId();
}
