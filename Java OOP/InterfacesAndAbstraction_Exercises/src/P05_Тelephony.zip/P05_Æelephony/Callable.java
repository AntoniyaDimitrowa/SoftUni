package P05_Тelephony;

public interface Callable {
    String call();
}
