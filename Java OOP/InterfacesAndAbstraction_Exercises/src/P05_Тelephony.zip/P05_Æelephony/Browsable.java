package P05_Тelephony;

public interface Browsable {
    String browse();
}
