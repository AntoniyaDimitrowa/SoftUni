package P02_MultipleImplementation;

public interface Identifiable {
    String getId();
}
