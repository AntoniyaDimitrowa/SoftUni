package P01_DefineAnInterfacePerson;

public interface Person {
    String getName();
    int getAge();
}
