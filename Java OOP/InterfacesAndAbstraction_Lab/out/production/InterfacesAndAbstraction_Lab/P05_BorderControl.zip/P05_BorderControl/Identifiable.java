package P05_BorderControl;

public interface Identifiable {
    String getId();
}
