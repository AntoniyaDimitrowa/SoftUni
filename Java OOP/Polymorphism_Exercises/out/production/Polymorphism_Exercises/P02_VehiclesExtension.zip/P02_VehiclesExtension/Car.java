package P02_VehiclesExtension;

public class Car extends Vehicle {

    private static final double ADDITIONAL_CONSUMPTION = 0.9;

    public Car(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        super(fuelQuantity, fuelConsumption, tankCapacity);
        addAdditionalConsumption();
    }

    @Override
    public void addAdditionalConsumption() {
        this.setFuelConsumption(this.getFuelConsumption() + ADDITIONAL_CONSUMPTION);
    }
}
